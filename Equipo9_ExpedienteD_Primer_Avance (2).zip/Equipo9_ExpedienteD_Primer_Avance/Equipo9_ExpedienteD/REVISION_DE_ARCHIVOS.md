# Revisión de archivos - Equipo 9, expediente D

Fecha de elaboración: 21/09/2026. Las fuentes son los nueve adjuntos y la aclaración del profesor pegada en la conversación.

## Inventario y uso

### Plantilla_Tablero_de_Evidencia (1)(2).docx

Plantilla de cuatro paginas: tres tarjetas y declaracion de IA. Copia binariamente identica a la segunda plantilla.

### Plantilla_Tablero_de_Evidencia(2).docx

Misma plantilla; se diligencio esta copia conservando sus campos y organizacion.

### 1 EDA(2).pptx

12 diapositivas, notas y valores de graficas: perfil, faltantes, duplicados, extremos, tres decisiones y entregable semana 1. Los ejemplos numericos son ilustrativos.

### 2 Asociación - evidencia(2).pptx

15 diapositivas y notas: objecion, comparaciones, confusoras, causalidad, potencia y panel semana 2. No se confundieron con tareas de la primera semana.

### Brief_Expediente_D(2).docx

Una pagina: rol, afirmacion presupuestal, criterio previo, razon monetaria, cruce avanzado y riesgos de escala/llave. Referencia a Guia general v2.0 no adjunta.

### Copia de SECOP_ExpedienteD_Grupo9(2).ipynb

Se revisaron todas las celdas y salidas. Conserva resultados de 17682 contratos y un error FileNotFoundError. No se reutilizaron. Diferencia de codigo respecto al base: Data/data.

### SECOP_ExpedienteD(2).ipynb

Se revisaron sus 31 celdas. Ruta principal con los CSV: contar identificadores por contrato, comparar, sintetizar evidencia y preparar objecion. No valida por si solo que un registro sea adicion monetaria.

### equipo_9-20260921T125448Z-1-001(2).zip

Se extrajo la carpeta equipo_9; contiene exactamente dos CSV y dos metadatos JSON. Se comprobaron tipos, filas, fechas, topes y cruce.

### Blog_DataAnalytics_SECOP-EDA(2).html

Lectura completa del texto y de las cuatro figuras. Expediente D usa dias_adicionados como ruta temporal; rubricacion y entregables incluidos. Figuras ilustrativas no usadas como resultados reales.

## Los cuatro archivos dentro del ZIP

| Archivo | Comprobación | Consecuencia |
|---|---|---|
| secop_recorte.csv | 50.000 filas, 85 columnas, IDs de contrato únicos. Todas las filas en Boyacá; firmas del 01/01/2024 al 31/12/2025. | Se usa completo como recorte asignado, sin escoger otros filtros. |
| metadata_extraccion.json | Equipo 9, expediente D, 62.017 registros disponibles, tope 50.000, recorte truncado. Extracción 16/09/2026. | No afirmar que es el universo completo ni una muestra aleatoria. |
| secop_adiciones.csv | 50.000 filas, cinco columnas, 49.912 eventos distintos, 78 duplicados exactos en exceso, 10 IDs con atributos conflictivos; fecha máxima 09/09/2024. | Contar eventos distintos, auditar conflictos y no interpretar ausencia de coincidencia como ausencia real de adición. |
| metadata_adiciones.json | Extracción nacional sin filtro territorial, tope 50.000, fecha 16/09/2026. | La fecha de extracción no asegura cobertura reciente de los eventos. |

## Diferencias entre materiales que no se resolvieron por suposición

El brief exige una razón presupuestal. El notebook D trabaja localización de eventos. El blog D permite examinar días adicionados. El análisis mantiene estos resultados separados: E1-E2 para registros localizados y E3 para tiempo. La razón monetaria queda no calculable con las variables validadas disponibles. Su ausencia no se llena con ceros.

No hay constancia de un criterio del equipo registrado antes de resultados. El criterio numérico del notebook preparado se identifica como propuesta exploratoria, no como prerregistro.

No se adjuntó la Guía general v2.0 ni una fecha y hora precisas de entrega. La objeción trabajada en el anexo es la del notebook base; no se inventa una nueva tarjeta del docente.

## Correspondencia del desarrollo con la actividad

El notebook preparado conserva la secuencia: cargar y comprobar fuentes; comprender filas y variables; describir distribuciones; revisar faltantes, duplicados, ceros, fechas y cinco extremos; agregar eventos y cruzar; auditar cobertura y cronología; comparar valor, duración y las categorías candidatas; producir exactamente tres tarjetas; documentar tres decisiones y uso de IA.

Como ampliación separada, el anexo compara conjuntamente por tipo, modalidad y año dentro de cuartiles de valor y completa el bloque de evidencia causal. No se presenta ese anexo como resolución de una objeción oficial aún no recibida.

## Fuentes externas consultadas solo para definiciones

- Colombia Compra Eficiente, SECOP II - Adiciones: https://www.datos.gov.co/Estad-sticas-Nacionales/SECOP-II-Adiciones/cb9c-h8sn
- Colombia Compra Eficiente / Socrata, Contratos Electrónicos: https://dev.socrata.com/foundry/www.datos.gov.co/jbjy-vk9h
- pandas, DataFrame.merge: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.merge.html

Consulta: 21/09/2026. No se sustituyeron las descargas del profesor por archivos actuales. No se verificaron los montos con documentos contractuales originales; los casos de revisión quedan exportados.

Las huellas y los tamaños de todas las fuentes están en inventario_fuentes.json. Los archivos originales de datos están en data/; las diapositivas y otros adjuntos del profesor no se duplican en este paquete.
